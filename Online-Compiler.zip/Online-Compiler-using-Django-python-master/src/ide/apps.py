from django.apps import AppConfig


class ideConfig(AppConfig):
    name = 'ide'